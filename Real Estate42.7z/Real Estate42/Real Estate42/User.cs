﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Real_Estate42
{
    public partial class User : Form
    {
        public User()
        {
            InitializeComponent();
        }

        private void User_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'real_Estate_DataDataSet3.Real_Estate_Data' table. You can move, or remove it, as needed.

        }

        private void sampleToolStripButton_Click(object sender, EventArgs e)
        {

        }
    }
}
